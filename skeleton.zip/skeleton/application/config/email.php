<?php defined('BASEPATH') OR exit('No direct script access allowed.');

$config['mailtype'] = 'html';
$config['smtp_host'] = 'localhost';
$config['smtp_port'] = 25;
$config['protocol'] = 'smtp';
$config['charset'] = 'utf-8';
$config['wordwrap'] = TRUE;
$config['newline'] = "\r\n";
