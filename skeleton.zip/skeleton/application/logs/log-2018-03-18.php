<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-03-18 03:58:27 --> UTF-8 Support Enabled
DEBUG - 2018-03-18 03:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-18 03:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-18 03:58:27 --> URI=examples/views/index
DEBUG - 2018-03-18 03:58:27 --> Total execution time: 0.0727
DEBUG - 2018-03-18 03:58:31 --> UTF-8 Support Enabled
DEBUG - 2018-03-18 03:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-18 03:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-18 03:58:31 --> URI=examples/views/noto
DEBUG - 2018-03-18 03:58:31 --> Total execution time: 0.0443
DEBUG - 2018-03-18 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2018-03-18 03:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-18 03:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-18 03:58:33 --> URI=examples/views/index
DEBUG - 2018-03-18 03:58:33 --> Total execution time: 0.0476
DEBUG - 2018-03-18 03:59:22 --> UTF-8 Support Enabled
DEBUG - 2018-03-18 03:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-18 03:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-18 03:59:23 --> URI=examples/views/richtext
DEBUG - 2018-03-18 03:59:23 --> Total execution time: 0.0953
DEBUG - 2018-03-18 03:59:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-18 03:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-18 03:59:23 --> 404 Page Not Found: Assets/ckeditor-4.7.3
DEBUG - 2018-03-18 03:59:23 --> UTF-8 Support Enabled
DEBUG - 2018-03-18 03:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-03-18 03:59:23 --> 404 Page Not Found: Assets/ckeditor-4.7.3
DEBUG - 2018-03-18 04:00:06 --> UTF-8 Support Enabled
DEBUG - 2018-03-18 04:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-03-18 04:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-03-18 04:00:06 --> URI=users
DEBUG - 2018-03-18 04:00:06 --> Total execution time: 0.0630
ERROR - 2018-03-18 04:07:12 --> 404 Page Not Found: Assets/examples
ERROR - 2018-03-18 04:07:20 --> 404 Page Not Found: Assets/js
ERROR - 2018-03-18 04:07:29 --> 404 Page Not Found: Assets/examples
ERROR - 2018-03-18 04:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2018-03-18 04:07:59 --> 404 Page Not Found: Assets/js
ERROR - 2018-03-18 04:15:37 --> 404 Page Not Found: Users1/index
ERROR - 2018-03-18 04:16:45 --> 404 Page Not Found: Users1/index
ERROR - 2018-03-18 04:16:55 --> 404 Page Not Found: Users1/index
ERROR - 2018-03-18 04:17:02 --> 404 Page Not Found: Users1/index
ERROR - 2018-03-18 04:18:14 --> 404 Page Not Found: Users1/index
ERROR - 2018-03-18 04:20:29 --> 404 Page Not Found: Errors/privileges
ERROR - 2018-03-18 04:20:34 --> 404 Page Not Found: Errors/privileges
