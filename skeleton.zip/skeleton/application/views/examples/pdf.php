<p>
  You can download the PDF by clicking on the link:
  <a href="<?php echo base_url();?>examples/backend/pdf/file/download">here</a>
</p>

<iframe src="<?php echo base_url();?>examples/backend/pdf/file/display" width="100%" height="100%"></iframe>
