<div id="container h-100">
	<div class="row h-100 justify-content-center align-items-center">
		<div class="d-flex align-content-center flex-wrap">
			<p><i class="mdi mdi-alert-octagram"></i> Sorry but your role doesn't allow you to perform this operation.</p>
		</div>
	</div>
</div>
